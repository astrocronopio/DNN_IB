
PI=3.14159265359 

def area(r):
	return	PI*r*r
	pass

def main():
	print(area(3))

if __name__ == '__main__':
	main()
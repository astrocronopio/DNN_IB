
def area(a,b):
	return	a*b
	pass

def main():
	print(area(3,7))

if __name__ == '__main__':
	main()
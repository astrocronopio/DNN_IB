
PI=3.14159265359 

def area(a,b):
	return	PI*a*b
	pass

def main():
	print(area(3,5))

if __name__ == '__main__':
	main()